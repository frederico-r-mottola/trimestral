package br.senai.repository;

import br.senai.model.Funcionario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FornecedorRepository extends JpaRepository<Fornecedor, Long> {

    public List<Fornecedor> findByCpf(String cpf);
    public List< Fornecedor> findByNomeAndEmail(String nome,String email);
    public List<Fornecedor> findByTelefoneLike(String telefone);

}
